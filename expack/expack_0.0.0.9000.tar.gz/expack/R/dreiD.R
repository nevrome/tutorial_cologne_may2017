coolplot <- function(points_df, type = "p", ...){
  rgl::plot3d(
    points_df[, 1], points_df[, 2], points_df[, 3],
    type = type,
    xlab = "x", ylab = "y", zlab = "z",
    ...
  )
}

coolpicture <- function(image, position) {
  rgl::show2d( { graphics::par(mar = rep(0, 4))
    graphics::plot( 0:1, 0:1, type = "n", ann = FALSE,
                    axes = FALSE, xaxs = "i", yaxs = "i" )
    graphics::rasterImage(image, 0, 0, 1, 1)
  },
  x = position[, 1], y = position[, 2], z = position[, 3]
  )
}
